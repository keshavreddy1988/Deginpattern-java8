/**
 * Provides an implementation of the Observer/Listener Design Pattern in Java 8.
 * 
 * @author Manoel Campos da Silva Filho
 */
package designpatterns.listener;
